/** Automatically generated file. DO NOT MODIFY */
package com.MobilePaintApp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}