package com.MobilePaintApp;

public class ForegroundService extends com.worklight.androidgap.WLForegroundService{
	//Nothing to do here...
}